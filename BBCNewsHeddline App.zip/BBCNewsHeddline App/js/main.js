/*$(document).ready(function(){
  $('#searchUser').on('keyup', function(e){
    let moviename = e.target.value;
   //console.log(moviename);
  $.ajax({
      url:'http://www.omdbapi.com/?t='+moviename,
      
    }).done(function(movie){
       // console.log(movie);
        $('#profile').html(`
        <div class="panel panel-default">
         
          <div class="panel-heading">
            <p> <img src="${movie.Poster}"></p>
            <br/>
            <h3 class="panel-title">Name:${movie.Title}</h3>
              <h3 class="panel-title">Director name:${movie.Director}</h3>
            <h3 class="panel-title">Realseed year:${movie.Year}</h>
             <h3 class="panel-title"> Rating:${movie.Ratings[0].Value}</h>
          </div>
         
          </div>
       <div class="col-md-12">
                  <a href="${movie.Website}" target="_blank" class="btn btn-default">Movie Page</a>
                </div>
        
      `);
        });
  });
});
*/
$(document).ready(function(){
   // $("#Search").keyup(function(e){
//var num=e.target.value;
//console.log(num);
$.ajax({

 url:'https://newsapi.org/v1/articles?source=bbc-news&sortBy=top&apiKey=92638b5c190a49319ed6e391cff00cfb',

    }).done(function(data){
       console.log(data);
    for(var i=0;i<data.articles.length;i++){
       $('#profile1').append(`
          <p> <img src="${data.articles[i].urlToImage}"></p>
           <br/>
           <a href="http://www.bbc.com/news/world" <h3 class="panel-title">Title:${data.articles[i].title}</h3></a>
            
            <br/>
            <h3 class="panel-title">Author:${data.articles[i].author}</h3>
             
            <h3 class="panel-title">Description:${data.articles[i].description}</h3>
             <br/>
           `);
         					//$('#profile').append('<li>'+'</br>'+data.articles[i].title+'</br>'+data.articles[i].author+'</li>');
       }

       
         /* for(var i=0;i<data.articles.length;i++){
         $('#profile').html(`
        <div class="panel panel-default">
         
          <div class="panel-heading">
            <p> <img src="${data.articles[i].urlToImage}"></p>
            <br/>
            <h3 class="panel-title">Title:${data.articles[i].title}</h3>
             <h3 class="panel-title">Author:${data.articles[i].author}</h3>
              <h3 class="panel-title">Description:${data.articles[i].description}</h3>
             
          </div>
         </div>
        
     `);
       }
         */
        });    
     
    });
    
