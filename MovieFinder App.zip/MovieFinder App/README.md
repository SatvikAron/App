# Github Finder

Searches Github.com user profiles and displays profile info and the latest repositories

### Version
1.0.0

## Usage

Open index.html