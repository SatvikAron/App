$(document).ready(function(){
 // $('#searchUser').on('keyup', function(e){
   // let moviename = e.target.value;
   //console.log(moviename);
  $.ajax({
      url:'http://api.flickr.com/services/feeds/photos_public.gne?jsoncallback=?&tags=flower&tagmode=any&format=json',
     
    }).done(function( data ) {
      $.each( data.items, function( i, item ) {
       // $( "<img>" ).attr( "src", item.media.m+'<br>' ).appendTo( "#images" );
          $( "#images1" ).append(`
            <p> <img src="${item.media.m}"></p>
          `);
            $( "#images1" ).append(  item.title );
        if ( i ===2 ) {
          return false;
        }
      });
    });
  })();
