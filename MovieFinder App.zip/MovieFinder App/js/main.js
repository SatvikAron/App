$(document).ready(function(){
  $('#searchUser').on('keyup', function(e){
    let moviename = e.target.value;
   //console.log(moviename);
  $.ajax({
      url:'http://www.omdbapi.com/?t='+moviename,
      
    }).done(function(movie){
       // console.log(movie);
        $('#profile').html(`
        <div class="panel panel-default">
         
          <div class="panel-heading">
            <p> <img src="${movie.Poster}"></p>
            <br/>
            <h3 class="panel-title">Name:${movie.Title}</h3>
              <h3 class="panel-title">Director name:${movie.Director}</h3>
            <h3 class="panel-title">Realseed year:${movie.Year}</h>
             <h3 class="panel-title"> Rating:${movie.Ratings[0].Value}</h>
          </div>
         
          </div>
       <div class="col-md-12">
                  <a href="${movie.Website}" target="_blank" class="btn btn-default">Movie Page</a>
                </div>
        
      `);
        });
  });
});
