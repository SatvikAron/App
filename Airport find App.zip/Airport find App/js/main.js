$(document).ready(function(){
  $('#searchUser').on('keyup', function(e){
    let city = e.target.value;
   //console.log(cityname);
  $.ajax({
     // url:'https://iatacodes.org/api/v6/cities?api_key=65a8f823-e238-4f99-bc73-8f928c380e7b&code='+city,
     url:'https://iatacodes.org/api/v6/countries?api_key=65a8f823-e238-4f99-bc73-8f928c380e7b&code='+city,
      
      // <h3 class="panel-title"> City Code:${city.response[0].code3}</h3>  
              //   <h3 class="panel-title"> City Code:${city.response[0].capital}</h3>  
                //   <h3 class="panel-title">Name of City:${city.response[0].population}</h3> 
            
    }).done(function(city){
        console.log(city);
   
        $('#profile').html(`
       
           
        <div class="panel panel-default">
          
           <h3 class="panel-title">Name of Country:${city.response[0].name}</h3>  
            
               <h3 class="panel-title"> Country Code:${city.response[0].code}</h3>  
                
            
         </diV>
        
        
      `);
    
        });
  });
});
